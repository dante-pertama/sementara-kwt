<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessedProductCategory extends Model
{
    protected $guarded = ['id'];
}
